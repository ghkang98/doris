/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.orc.bench.core.convert.orc;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hive.ql.exec.vector.VectorizedRowBatch;
import org.apache.orc.OrcFile;
import org.apache.orc.Reader;
import org.apache.orc.RecordReader;
import org.apache.orc.TypeDescription;
import org.apache.orc.bench.core.convert.BatchReader;

import java.io.IOException;

public class OrcReader implements BatchReader {
  private final RecordReader reader;

  public OrcReader(Path path,
                   TypeDescription schema,
                   Configuration conf
                   ) throws IOException {
    Reader file = OrcFile.createReader(path, OrcFile.readerOptions(conf));
    reader = file.rows(file.options().schema(schema));
  }

  public boolean nextBatch(VectorizedRowBatch batch) throws IOException {
    return reader.nextBatch(batch);
  }

  public void close() throws IOException {
    reader.close();
  }
}
