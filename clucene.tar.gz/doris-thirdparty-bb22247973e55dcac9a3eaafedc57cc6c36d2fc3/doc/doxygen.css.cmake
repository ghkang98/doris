H1 {
        text-align: center;
        font-family: Arial, Helvetica, sans-serif;
}
H2 {
        font-family: Geneva, Arial, Helvetica, sans-serif;
}
CAPTION { font-weight: bold }
DIV.qindex { width: 100%;
             background-color: #eeeeff;
             border: 4px solid #eeeeff;
             text-align: center;
             margin-bottom: 2px
}
A.qindex { text-decoration: none; font-weight: bold; }
A.qindex:hover { text-decoration: none; background-color: #ddddff }
A.qindexHL { text-decoration: none; font-weight: bold;
             background-color: #6666cc;
             color: #ffffff
           }
A.qindexHL:hover { text-decoration: none; background-color: #6666cc }
A.qindexRef { text-decoration: none; font-weight: bold; }
A.qindexRef:hover { text-decoration: none; background-color: #ddddff }
A.qindexRefHL { text-decoration: none; font-weight: bold;
             background-color: #6666cc;
             color: #ffffff
           }
A.qindexRefHL:hover { text-decoration: none; background-color: #6666cc }
A.el { text-decoration: none; font-weight: bold }
A.elRef { font-weight: bold }
A.code { text-decoration: none; font-weight: normal; color: #4444ee }
A.codeRef { font-weight: normal; color: #4444ee }
A:hover { text-decoration: none; background-color: #f2f2ff }
DL.el { margin-left: -1cm }
DIV.fragment {
        width: 98%;
        border: 1px solid #CCCCCC;
        background-color: #f5f5f5;
        padding-left: 4px;
        margin: 4px;
}
DIV.ah { background-color: black; font-weight: bold; color: #ffffff; 
margin-bottom: 3px; margin-top: 3px }
TD.md { background-color: #f2f2ff; font-weight: bold; }
TD.mdname1 { background-color: #f2f2ff; font-weight: bold; color: #602020; }
TD.mdname { background-color: #f2f2ff; font-weight: bold; color: #602020; 
width: 600px; }
DIV.groupHeader { margin-left: 16px; margin-top: 12px; margin-bottom: 6px; 
font-weight: bold }
DIV.groupText { margin-left: 16px; font-style: italic; font-size: smaller }
BODY {
        background: white;
        color: black;
        margin-right: 20px;
        margin-left: 20px;
}
TD.indexkey { 
   background-color: #eeeeff; 
   font-weight: bold; 
   padding-right  : 10px; 
   padding-top    : 2px; 
   padding-left   : 10px; 
   padding-bottom : 2px; 
   margin-left    : 0px; 
   margin-right   : 0px; 
   margin-top     : 2px; 
   margin-bottom  : 2px  
}
TD.indexvalue { 
   background-color: #eeeeff; 
   font-style: italic; 
   padding-right  : 10px; 
   padding-top    : 2px; 
   padding-left   : 10px; 
   padding-bottom : 2px; 
   margin-left    : 0px; 
   margin-right   : 0px; 
   margin-top     : 2px; 
   margin-bottom  : 2px  
}
TR.memlist {
   background-color: #f0f0f0; 
}
P.formulaDsp { text-align: center; }
IMG.formulaDsp { }
IMG.formulaInl { vertical-align: middle; }
SPAN.keyword       { color: #008000 }
SPAN.keywordtype   { color: #604020 }
SPAN.keywordflow   { color: #e08000 }
SPAN.comment       { color: #800000 }
SPAN.preprocessor  { color: #806020 }
SPAN.stringliteral { color: #002080 }
SPAN.charliteral   { color: #008080 }
.mdTable {
        border: 1px solid #868686;
        background-color: #f2f2ff;
}
.mdRow {
        padding: 8px 20px;
}
.mdescLeft {
        font-size: smaller;
        font-family: Arial, Helvetica, sans-serif;
        background-color: #FAFAFA;
        padding-left: 8px;
        border-top: 1px none #E0E0E0;
        border-right: 1px none #E0E0E0;
        border-bottom: 1px none #E0E0E0;
        border-left: 1px none #E0E0E0;
        margin: 0px;
}
.mdescRight {
        font-size: smaller;
        font-family: Arial, Helvetica, sans-serif;
        font-style: italic;
        background-color: #FAFAFA;
        padding-left: 4px;
        border-top: 1px none #E0E0E0;
        border-right: 1px none #E0E0E0;
        border-bottom: 1px none #E0E0E0;
        border-left: 1px none #E0E0E0;
        margin: 0px;
        padding-bottom: 0px;
        padding-right: 8px;
}
.memItemLeft {
        padding: 1px 0px 0px 8px;
        margin: 4px;
        border-top-width: 1px;
        border-right-width: 1px;
        border-bottom-width: 1px;
        border-left-width: 1px;
        border-top-style: solid;
        border-top-color: #E0E0E0;
        border-right-color: #E0E0E0;
        border-bottom-color: #E0E0E0;
        border-left-color: #E0E0E0;
        border-right-style: none;
        border-bottom-style: none;
        border-left-style: none;
        background-color: #FAFAFA;
        font-family: Geneva, Arial, Helvetica, sans-serif;
        font-size: 12px;
}
.memItemRight {
        padding: 1px 0px 0px 8px;
        margin: 4px;
        border-top-width: 1px;
        border-right-width: 1px;
        border-bottom-width: 1px;
        border-left-width: 1px;
        border-top-style: solid;
        border-top-color: #E0E0E0;
        border-right-color: #E0E0E0;
        border-bottom-color: #E0E0E0;
        border-left-color: #E0E0E0;
        border-right-style: none;
        border-bottom-style: none;
        border-left-style: none;
        background-color: #FAFAFA;
        font-family: Geneva, Arial, Helvetica, sans-serif;
        font-size: 13px;
}
